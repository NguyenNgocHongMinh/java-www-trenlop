package com.se.nguyenngochongminh_shopping_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NguyenNgocHongMinhShoppingThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
