INSERT INTO categories (name) VALUES
                                  ('điện thoại'),
                                  ('IOS'),
                                  ('Tai nghe');
INSERT INTO products (name, price, in_stock, category_id) VALUES
                                                              ('Iphone 15', 1200.00, 1, 1),
                                                              ('Macbook Air', 1500.00, 0, 2),
                                                              ('AirPods Pro', 250.00, 1, 3);

INSERT INTO comments (text, product_id) VALUES
                                            ('Sản phẩm rất tốt', 1),
                                            ('Giá hơi cao nhưng đáng tiền', 1),
                                            ('Giao hàng nhanh', 2);

customer/111
admin/123